 

<!--payment-->
<div class="container-fluid" style="background: #eeeeee;">
<div class="container">
    <div class="f-four">
<div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-4">
<div class="col-lg-12">
    <div class="col-lg-6">
        <img src="img/payment/404.png" />
    </div>
    <div class="col-lg-6">
        <div class="text-f-f">
            <h3>Oops !</h3>
            <h4><span>404</span>Error</h4>
            <h5>Page not found</h5>
        </div>

    </div>
</div>
    </div>
    <div class="col-lg-4"></div>
</div>
    </div>
</div>

</div>

<!--payment-->
 